import dijkstra
import RestApi
import json

def get_graph():
    links=RestApi.get_all_links()
    switches=RestApi.get_all_switches()
    graph={}
    for i in range(len(switches)):
        graph[switches[i]['dpid']]={}
    for i in range(len(links)):
        graph[links[i]['src']['dpid']][links[i]['dst']['dpid']]=1
    return graph

def get_switch_ports():
    links=RestApi.get_all_links()  
    switches=RestApi.get_all_switches()
    switch_ports={}
    for i in range(len(switches)):
        switch_ports[switches[i]['dpid']]={}
    for i in range(len(links)):
        switch_ports[links[i]['src']['dpid']][links[i]['dst']['dpid']]=links[i]['src']['port_no']
    return switch_ports

#get the dpid and port_no of switch connected to hosts
def get_host_snp():
    switches=RestApi.get_all_switches()
    hosts_dpid={}
    hosts_port={}
    for i in range(len(switches)):
        host_of_it=RestApi.get_hosts(switches[i]['dpid'])
        for j in range(len(host_of_it)):
            hosts_dpid[host_of_it[j]['ipv4'][0]]=switches[i]['dpid']
            hosts_port[host_of_it[j]['ipv4'][0]]=host_of_it[j]['port']['port_no']
    return hosts_dpid,hosts_port
    
    

def LS_add_flows(switches,graph,switch_ports,hosts_dpid):   
    for i in range(len(switches)):
        dpid=switches[i]['dpid']
        paths=dijkstra.all_pairs_shortest_path(graph)
        for j in hosts_dpid:
            if (hosts_dpid[j]==dpid):
                pass
            else:
                if (paths[dpid][hosts_dpid[j]]!=None):
                    match={
                        "nw_dst":j+'/24',
                        "dl_type":2048
                    }
                    out_port=int(switch_ports[dpid][paths[dpid][hosts_dpid[j]]])
                    actions=[{"type":"OUTPUT","port":out_port}]
                    print(RestApi.add_flow_entry(int(dpid),match,32766,actions))

switches=RestApi.get_all_switches()
graph=get_graph()
switch_ports=get_switch_ports()
hosts_dpid,hosts_port=get_host_snp()
LS_add_flows(switches,graph,switch_ports,hosts_dpid)
