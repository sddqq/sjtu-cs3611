import heapq

def dijkstra(graph, start):
    #initial the data
    min_heap = [(0, start)]
    distances = {node: float('infinity') for node in graph}
    distances[start] = 0
    predecessors = {node: None for node in graph}
    first_steps = {node: None for node in graph}
    while min_heap:
        current_distance, current_node = heapq.heappop(min_heap)
        if current_distance > distances[current_node]:
            continue
        for neighbor, weight in graph[current_node].items():
            distance = current_distance + weight
            if distance < distances[neighbor]:
                distances[neighbor] = distance
                predecessors[neighbor] = current_node
                heapq.heappush(min_heap, (distance, neighbor))
                # update
                if current_node == start:
                    first_steps[neighbor] = neighbor
                else:
                    first_steps[neighbor] = first_steps[current_node]
    return distances, first_steps

#get the first step in the path
def all_pairs_shortest_path(graph):
    all_first_steps = {}
    for start_node in graph:
        _, first_steps = dijkstra(graph, start_node)
        all_first_steps[start_node] = first_steps
    return all_first_steps