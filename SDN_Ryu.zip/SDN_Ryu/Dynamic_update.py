import RestApi
import LS_Algorithm as LS


switches=RestApi.get_all_switches()
graph=LS.get_graph()
switch_ports=LS.get_switch_ports()
hosts_dpid,hosts_port=LS.get_host_snp()
LS.LS_add_flows(switches,graph,switch_ports,hosts_dpid)

last_graph={}
while True:
    last_graph=graph
    graph=LS.get_graph()
    if (last_graph==graph):
        pass
    else:
        print(graph)
        switches=RestApi.get_all_switches()
        switch_ports=LS.get_switch_ports()
        hosts_dpid,hosts_port=LS.get_host_snp()
        LS.LS_add_flows(switches,graph,switch_ports,hosts_dpid)
