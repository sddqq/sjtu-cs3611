import json
import urllib.request
def get_all_switches():
    url="http://127.0.0.1:8080/v1.0/topology/switches"
    req=urllib.request.Request(url)
    res_data=urllib.request.urlopen(req)
    res=res_data.read()
    res=json.loads(res)
    return res

def get_all_links():
    url="http://127.0.0.1:8080/v1.0/topology/links"
    req=urllib.request.Request(url)
    res_data=urllib.request.urlopen(req)
    res = res_data.read()
    res =json.loads(res)
    return res

def get_switch(dpid):
    url="http://127.0.0.1:8080/v1.0/topology/switches/"+dpid
    req=urllib.request.Request(url)
    res_data=urllib.request.urlopen(req)
    res=res_data.read()
    res=json.loads(res)
    return res

def get_hosts(dpid):
    url="http://127.0.0.1:8080/v1.0/topology/hosts/"+dpid
    req=urllib.request.Request(url)
    res_data=urllib.request.urlopen(req)
    res=res_data.read()
    res=json.loads(res)
    return res

#为dpid对应的交换机添加流表
def add_flow_entry(dpid,match,priority,actions):
    url="http://127.0.0.1:8080/stats/flowentry/add"
    post_data=json.dumps({
        'dpid':dpid,
        'match':match,
        'priority':priority,
        'actions':actions
    }).encode('utf-8')
    req=urllib.request.Request(url,data=post_data,headers={'Content-Type':'application/json'})
    with urllib.request.urlopen(req) as response:
        return response.getcode()
        
def delete_flow_entry(dpid, match=None, priority=None, actions=None):
    url = "http://127.0.0.1:8080/stats/flowentry/delete_strict"
    post_data = {'dpid': dpid}
    if match is not None:
        post_data['match'] = match
    if priority is not None:
        post_data['priority'] = priority
    if actions is not None:
        post_data['actions'] = actions
    post_data = json.dumps(post_data).encode('utf-8')
    req = urllib.request.Request(url, data=post_data, headers={'Content-Type': 'application/json'})
    with urllib.request.urlopen(req) as res:
        return res.getcode()
