import RestApi
print(RestApi.delete_flow_entry(1,None,32766,None))
