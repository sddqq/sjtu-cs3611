## 一、静态路由选择

### 	  1.流表下发方法的选取

首先，通过网上查询，我们了解到可以通过ryu中的app_manager写一个自己的	RyuApp，类似于ryu库中自带的各种app，来实现我们想要的功能，但是这种方法上手难度较大，需要学习的东西太多。
然后，仔细阅读题目以及readme.md里给出的几个链接，我们知道还可以用ryu里已经写好的Rest API 直接通过HTTP请求来得到网络拓扑的信息，并实现流表的下发，所以我们选择了这种方法。

### 2.流表下发的算法实现

首先，我们用urllib.request库，将对Rest API的请求封装成不同的函数保存在RestApi.py中，形式如下：

``````python
def get_all_switches():
    url="http://127.0.0.1:8080/v1.0/topology/switches"
    req=urllib.request.Request(url)
    res_data=urllib.request.urlopen(req)
    res=res_data.read()
    res=json.loads(res)
    return res
``````

然后，编写dijkstra算法，用于计算最佳转发路径。其中图以列表的形式存储，类似下面的形式：

``````python
{'A': {'C': 1, 'B': 1}, 
 'B': {'C': 1, 'A': 1}, 
 'C': {'A': 1, 'B': 1}}
``````

因为在后面通过GET请求得到的links是有向的，所以我们写的是适用于有向图的算法。其中可以存储每条边的权重，在后面可将链路的延迟、带宽等加入用来做负载均衡策略，不过我们没有选择实现这一功能。随后，用all_pairs_shortest_path（graph）函数来直接得到每条最优路径上的第一个点（除自己外），方便后面使用。

``````python
def dijkstra(graph, start):
    #initial the data
    min_heap = [(0, start)]
    distances = {node: float('infinity') for node in graph}
    distances[start] = 0
    predecessors = {node: None for node in graph}
    first_steps = {node: None for node in graph}
    while min_heap:
        current_distance, current_node = heapq.heappop(min_heap)
        if current_distance > distances[current_node]:
            continue
        for neighbor, weight in graph[current_node].items():
            distance = current_distance + weight
            if distance < distances[neighbor]:
                distances[neighbor] = distance
                predecessors[neighbor] = current_node
                heapq.heappush(min_heap, (distance, neighbor))
                # update
                if current_node == start:
                    first_steps[neighbor] = neighbor
                else:
                    first_steps[neighbor] = first_steps[current_node]
    return distances, first_steps

#get the first step in the path
def all_pairs_shortest_path(graph):
    all_first_steps = {}
    for start_node in graph:
        _, first_steps = dijkstra(graph, start_node)
        all_first_steps[start_node] = first_steps
    return all_first_steps
``````

然后完成静态路由选择算法的实现：

先用get_graph()函数将链路状态存储为dijkstra()函数需要的形式：

``````python
def get_graph():
    links=RestApi.get_all_links()
    switches=RestApi.get_all_switches()
    graph={}
    for i in range(len(switches)):
        graph[switches[i]['dpid']]={}
    for i in range(len(links)):
        graph[links[i]['src']['dpid']][links[i]['dst']['dpid']]=1
    return graph
``````

然后用类似的方式，用get_switch_ports()函数得到每个交换机与其他交换机相连的端口，用get_host_snp()函数得到每个主机连接的交换机的dpid以及连接到交换机上的哪个端口，分别用两个列表存储。

然后，用API获取需要的信息，调用LS_add_flows()函数，根据GET到的拓扑信息进行流表下发。在LS_add_flows()中，对每个不与交换机相连的主机，根据dijkstra算法得到的最短路径上的第一个点，找到交换机与其相连的端口，通过添加流表将信息转发到相应端口。

``````python
def LS_add_flows(switches,graph,switch_ports,hosts_dpid):   
    for i in range(len(switches)):
        dpid=switches[i]['dpid']
        paths=dijkstra.all_pairs_shortest_path(graph)
        for j in hosts_dpid:
            if (hosts_dpid[j]==dpid):
                pass
            else:
                if (paths[dpid][hosts_dpid[j]]!=None):
                    match={
                        "nw_dst":j+'/24',
                        "dl_type":2048
                    }
                    out_port=int(switch_ports[dpid][paths[dpid][hosts_dpid[j]]])
                    actions=[{"type":"OUTPUT","port":out_port}]
                    print(RestApi.add_flow_entry(int(dpid),match,32766,actions))
switches=RestApi.get_all_switches()
graph=get_graph()
switch_ports=get_switch_ports()
hosts_dpid,hosts_port=get_host_snp()
LS_add_flows(switches,graph,switch_ports,hosts_dpid)                    
``````

然而，在运行上述算法后，我们发现并没有达到预期的效果，各个主机之间还是ping不通。经过长时间的排查，我们发现在net_start.py中，有这样的一段代码发送了一系列POST请求：

``````
c0.cmd(
    ''' curl -X POST -d '{"address": "223.1.1.1/24"}' http://localhost:8080/router/0000000000000001 ''')
``````

但是我们在ryu的终端里并没有发现POST请求，后来我们发现是由于curl没装，安装后程序可以正常使用。

## 二、动态更新流表

在这一问中，我们选择了一种简单粗暴的方法：不断使用get_graph()函数来获取网络拓扑图，并与上一个状态的图进行比较，如果二者不相同，就再次运行LS_add_flows()函数来进行流表下发。而且我们发现，在这样的方法中，虽然进行流表下发使用的是add_flow_entry(dpid)，但是并不会每次都在交换机中添加流表，而是直接修改了之前添加的流表，所以这种方法完全可以实现我们的需求。

``````python
switches=RestApi.get_all_switches()
graph=LS.get_graph()
switch_ports=LS.get_switch_ports()
hosts_dpid,hosts_port=LS.get_host_snp()
LS.LS_add_flows(switches,graph,switch_ports,hosts_dpid)

last_graph={}
while True:
    last_graph=graph
    graph=LS.get_graph()
    if (last_graph==graph):
        pass
    else:
        print(graph)
        switches=RestApi.get_all_switches()
        switch_ports=LS.get_switch_ports()
        hosts_dpid,hosts_port=LS.get_host_snp()
        LS.LS_add_flows(switches,graph,switch_ports,hosts_dpid)
``````

## 三、配置s2的流表，实现一些特殊功能

​	1.仅有TCP流量被允许传递到主机h2(即UDP流量被阻塞)

​	通过add_flow_entry函数添加s2的流表，使得目的地址为s2的ip地址的流量，通过drop UDP流量（proto为17），实现只有tcp流量被允许传到主机

```
match = {
    "nw_dst":"223.1.2.2",
    "dl_type":2048,
    "nw_proto":17
}
RestApi.add_flow_entry(2, match, 32769, [{"actions":"drop"}])	
```

​	2.所有从h2发出的流量目的地址均被改为h1。

​	通过add_flow_entry函数添加s2的流表，修改输入端口为1，源ip地址为h2流量的目的地址为h1，并通过2端口进行转发

```
match = {  
    "in_port": 1, 
    "dl_type": 2048, 
    "ipv4_src": "223.1.2.2",
} 
actions = [  
    {  
        "type": "SET_FIELD",  
        "field": "ipv4_dst",  
        "value": "223.1.1.2" 
    },  
    {  
        "type": "OUTPUT",  
        "port": 2   
    }  
]  
RestApi.add_flow_entry(2, match 32769, actions)
```
